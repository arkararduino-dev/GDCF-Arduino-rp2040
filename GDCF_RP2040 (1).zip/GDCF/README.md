# GDCF - Graph-Driven Compute Fabric (RP2040)

A token-based dataflow execution engine for the Raspberry Pi Pico (RP2040) built
on the Earle Philhower Arduino-Pico core.

Features:
- Static memory pool (no heap fragmentation)
- Dual-core scheduler (core0 dispatches, core1 executes)
- DMA engine wrapper
- PIO shift-token program
- MAC pipeline for matrix multiply / FIR / CNN kernels
- Simple graph compiler

See `examples/` for usage.

## Tuning SRAM usage

All pools are static and sized at compile time via four macros in
`src/Config.h`:

| Macro                  | Default | Purpose                            |
| ---------------------- | ------- | ---------------------------------- |
| `GDCF_MAX_TOKENS`      | 64      | Static Token pool depth            |
| `GDCF_TOKEN_PAYLOAD`   | 4       | Float lanes per Token              |
| `GDCF_MAX_NODES`       | 32      | Maximum graph nodes                |
| `GDCF_NODE_BLOCK_SIZE` | 64      | Per-node scratch block (bytes)     |

Override from a sketch:

```cpp
#define GDCF_MAX_TOKENS    128
#define GDCF_TOKEN_PAYLOAD 8
#include <GDCF.h>
```

or via a build flag: `-DGDCF_MAX_TOKENS=128`.

Full sizing formulas, recipes, and diagnostics: [`docs/TUNING.md`](docs/TUNING.md).

## Continuous Integration

`.github/workflows/compile-examples.yml` runs on every push and pull request:

- Compiles every sketch under `examples/` with `arduino/compile-sketches@v1`
  against the [Arduino-Pico core](https://github.com/earlephilhower/arduino-pico)
  on the `rpipico`, `rpipicow`, and `rpipico2` FQBNs. Warnings are set to `all`
  and reported per build.
- On success, packages the library into `GDCF_RP2040.zip` and uploads it as a
  workflow artifact you can download from the Actions run.

Run it manually from the Actions tab via **Run workflow** (`workflow_dispatch`).
