#!/usr/bin/env bash
# summarize-ci.sh
#
# Reads GitHub Actions logs for a workflow run and produces a concise
# per-sketch / per-board pass/fail table. Designed to run inside a
# GitHub Actions job (writes to $GITHUB_STEP_SUMMARY when set) but can
# also be invoked locally with the `gh` CLI installed.
#
# Usage (inside a workflow):
#   ./scripts/summarize-ci.sh                # uses $GITHUB_RUN_ID
#
# Usage (locally):
#   gh auth login
#   ./scripts/summarize-ci.sh <run-id> [owner/repo]

set -euo pipefail

RUN_ID="${1:-${GITHUB_RUN_ID:-}}"
REPO="${2:-${GITHUB_REPOSITORY:-}}"

if [[ -z "${RUN_ID}" ]]; then
  echo "error: run id required (arg 1 or GITHUB_RUN_ID)" >&2
  exit 2
fi

if ! command -v gh >/dev/null 2>&1; then
  echo "error: gh CLI not found on PATH" >&2
  exit 2
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "Fetching logs for run ${RUN_ID}${REPO:+ (${REPO})} ..." >&2
if [[ -n "${REPO}" ]]; then
  gh run view "${RUN_ID}" --repo "${REPO}" --log > "${WORK}/all.log" || true
  gh run view "${RUN_ID}" --repo "${REPO}" --json jobs \
    --jq '.jobs[] | [.name, .conclusion] | @tsv' > "${WORK}/jobs.tsv"
else
  gh run view "${RUN_ID}" --log > "${WORK}/all.log" || true
  gh run view "${RUN_ID}" --json jobs \
    --jq '.jobs[] | [.name, .conclusion] | @tsv' > "${WORK}/jobs.tsv"
fi

# Build a markdown summary. Each matrix job is named like:
#   "Compile examples/FIRFilter for rp2040:rp2040:rpipicow"
SUMMARY="${GITHUB_STEP_SUMMARY:-${WORK}/summary.md}"

{
  echo "# GDCF CI Summary"
  echo ""
  echo "Run: \`${RUN_ID}\`"
  echo ""
  echo "| Sketch | Board | Result |"
  echo "|--------|-------|--------|"
} >> "${SUMMARY}"

pass=0; fail=0; other=0
while IFS=$'\t' read -r name conclusion; do
  # Only summarize the compile matrix jobs.
  if [[ "${name}" =~ ^Compile[[:space:]]+examples/([A-Za-z0-9_]+)[[:space:]]+for[[:space:]]+(.+)$ ]]; then
    sketch="${BASH_REMATCH[1]}"
    board="${BASH_REMATCH[2]}"
    case "${conclusion}" in
      success)  icon="✅ pass"; pass=$((pass+1)) ;;
      failure)  icon="❌ fail"; fail=$((fail+1)) ;;
      cancelled|skipped) icon="⚪ ${conclusion}"; other=$((other+1)) ;;
      *)        icon="❔ ${conclusion:-unknown}"; other=$((other+1)) ;;
    esac
    echo "| \`${sketch}\` | \`${board}\` | ${icon} |" >> "${SUMMARY}"
  fi
done < "${WORK}/jobs.tsv"

{
  echo ""
  echo "**Totals:** ${pass} pass · ${fail} fail · ${other} other"
} >> "${SUMMARY}"

# Extract the first compiler error line per failing sketch for quick triage.
if grep -qE '\berror:' "${WORK}/all.log" 2>/dev/null; then
  {
    echo ""
    echo "## First error per failing job"
    echo ""
    echo '```'
    # gh run --log prefixes lines with "<job-name>\t<step>\t<line>".
    awk -F'\t' '
      /error:/ && !seen[$1]++ {
        print $1 " :: " $NF
      }
    ' "${WORK}/all.log" | head -n 40
    echo '```'
  } >> "${SUMMARY}"
fi

echo "Wrote summary to ${SUMMARY}" >&2
[[ "${fail}" -eq 0 ]]
