# GDCF SRAM Tuning Guide

GDCF preallocates all runtime state at boot — there is no heap use. That
means SRAM footprint is a direct function of four compile-time constants,
all defined in `src/Config.h` and all overridable from your sketch or
build flags.

## The four knobs

| Macro                   | Default | What it controls                              |
| ----------------------- | ------- | --------------------------------------------- |
| `GDCF_MAX_TOKENS`       | 64      | Size of the static Token pool                 |
| `GDCF_TOKEN_PAYLOAD`    | 4       | Float lanes carried inside each Token         |
| `GDCF_MAX_NODES`        | 32      | Maximum graph nodes                           |
| `GDCF_NODE_BLOCK_SIZE`  | 64      | Per-node scratch block, in bytes              |

## SRAM cost formula

```
Token size    = 8 B header + 4 B * GDCF_TOKEN_PAYLOAD
Token pool    = GDCF_MAX_TOKENS * (Token size + 1)   // +1 for used_[] flag
Node pool     = GDCF_MAX_NODES  * GDCF_NODE_BLOCK_SIZE
Graph table   = GDCF_MAX_NODES  * sizeof(Node)       // ~32 B/node
Total pool ~= Token pool + Node pool + Graph table
```

Defaults on RP2040:

```
Token pool  = 64 * (8 + 16 + 1) = 1 600 B
Node pool   = 32 * 64           = 2 048 B
Graph table = 32 * 32           = 1 024 B
Total       ~= 4.6 KB of the 264 KB SRAM
```

## How to override

Either add a build flag:

```
-DGDCF_MAX_TOKENS=128 -DGDCF_TOKEN_PAYLOAD=8
```

or `#define` before the include in your sketch:

```cpp
#define GDCF_MAX_TOKENS      128
#define GDCF_TOKEN_PAYLOAD   8
#define GDCF_MAX_NODES       48
#define GDCF_NODE_BLOCK_SIZE 96
#include <GDCF.h>
```

The overrides must be visible before *any* GDCF header is included, so put
them at the very top of the translation unit.

## Sizing recipes

- **Tiny sensor pipeline (<1 KB pool).** `MAX_TOKENS=16`,
  `TOKEN_PAYLOAD=2`, `MAX_NODES=8`, `NODE_BLOCK_SIZE=32`.
- **FIR / small DSP graph.** Defaults are fine; bump `TOKEN_PAYLOAD` to 8
  if each sample carries stereo + metadata.
- **CNN / matrix workloads.** Raise `MAX_TOKENS` to 128–256 to keep both
  cores fed, and `NODE_BLOCK_SIZE` to 128+ so per-layer state fits.
- **Deeper graphs.** Increase only `MAX_NODES`; token traffic is usually
  unchanged.

## Diagnosing pressure

- `MemoryPool::tokensInUse()` — sample this from your loop; if it
  stays near `maxTokens()` you are token-starved, raise `MAX_TOKENS`.
- `Graph::addNode` returns `-1` — you hit `GDCF_MAX_NODES`.
- `allocNodeBlock` returns `nullptr` — node index >= `MAX_NODES`.
- Build error "array too large" or link-time SRAM overflow — the pool
  no longer fits; lower one of the four knobs.

## Rules of thumb

- Keep `GDCF_TOKEN_PAYLOAD` a power of two; the MAC pipeline unrolls on it.
- `GDCF_MAX_TOKENS` should be at least 2× the fan-out of your busiest node.
- `GDCF_NODE_BLOCK_SIZE` must be >= the largest per-node state struct you
  place in it; there is no runtime check that catches undersizing.
