#include "Router.h"

namespace gdcf {

Router::Router(MemoryPool& pool) : pool_(pool), nEdges_(0), head_(0), tail_(0) {}

bool Router::addEdge(uint16_t fromNode, uint16_t fromPort,
                     uint16_t toNode,   uint16_t toPort) {
  if (nEdges_ >= 64) return false;
  edges_[nEdges_++] = Edge{fromNode, fromPort, toNode, toPort};
  return true;
}

void Router::emit(uint16_t fromNode, uint16_t fromPort, const Token& tok) {
  for (uint16_t i = 0; i < nEdges_; ++i) {
    const Edge& e = edges_[i];
    if (e.fromNode == fromNode && e.fromPort == fromPort) {
      Token t = tok;
      t.tag  = e.toNode;
      t.port = e.toPort;
      t.flags |= TOKEN_FLAG_VALID;
      push(t);
    }
  }
}

bool Router::push(const Token& tok) {
  uint16_t next = (uint16_t)((head_ + 1) % GDCF_QUEUE_SIZE);
  if (next == tail_) return false; // full
  queue_[head_] = tok;
  head_ = next;
  return true;
}

bool Router::pop(Token& out) {
  if (tail_ == head_) return false;
  out = queue_[tail_];
  tail_ = (uint16_t)((tail_ + 1) % GDCF_QUEUE_SIZE);
  return true;
}

} // namespace gdcf
