#include "Scheduler.h"
#include <pico/multicore.h>
#include <pico/platform.h>

namespace gdcf {

static Scheduler* s_instance = nullptr;

static void core1_entry() {
  if (s_instance) s_instance->workerLoop();
}

Scheduler::Scheduler(Graph& graph)
    : graph_(graph), executed_(0), running_(false) {}

void Scheduler::begin() {
  s_instance = this;
  running_ = true;
  multicore_reset_core1();
  multicore_launch_core1(core1_entry);
}

void Scheduler::dispatch(const Token& seed) {
  graph_.router().push(seed);
}

bool Scheduler::step() {
  Token t;
  if (!graph_.router().pop(t)) return false;
  Node* n = graph_.node(t.tag);
  if (n) {
    nodeExecute(*n, t, graph_.router());
    ++executed_;
  }
  return true;
}

void Scheduler::workerLoop() {
  while (running_) {
    if (!step()) {
      tight_loop_contents();
    }
  }
}

} // namespace gdcf
