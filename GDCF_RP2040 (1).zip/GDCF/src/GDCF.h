#pragma once

// Umbrella header for the GDCF (Graph-Driven Compute Fabric) library.
#include "Token.h"
#include "MemoryPool.h"
#include "Node.h"
#include "Router.h"
#include "Graph.h"
#include "Scheduler.h"
#include "DMAEngine.h"
#include "PIOEngine.h"
#include "MACPipeline.h"
#include "Compiler.h"
#include "Utilities.h"

namespace gdcf {

class GDCF {
 public:
  GDCF();

  Graph&       graph()     { return graph_; }
  Router&      router()    { return router_; }
  MemoryPool&  pool()      { return pool_; }
  Scheduler&   scheduler() { return sched_; }
  MACPipeline& mac()       { return mac_; }

  void begin();
  bool step();
  void dispatch(const Token& t) { sched_.dispatch(t); }

 private:
  MemoryPool  pool_;
  Router      router_;
  Graph       graph_;
  Scheduler   sched_;
  MACPipeline mac_;
};

} // namespace gdcf
