#pragma once
#include <stdint.h>
#include <stddef.h>

namespace gdcf {

class MACPipeline {
 public:
  MACPipeline();

  // acc += sum(a[i] * b[i]) for i in [0,n)
  float dot(const float* a, const float* b, size_t n);

  // out[i] = sum_k a[i*K + k] * b[k]
  void  matVec(const float* A, const float* x, float* y,
               size_t M, size_t K);

  // FIR: y[n] = sum_{k=0..taps-1} coeffs[k] * x[n-k]
  float fir(const float* coeffs, const float* window, size_t taps);
};

} // namespace gdcf
