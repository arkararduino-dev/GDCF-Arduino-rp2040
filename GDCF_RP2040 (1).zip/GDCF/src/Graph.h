#pragma once
#include <stdint.h>
#include "Node.h"
#include "Router.h"
#include "MemoryPool.h"

namespace gdcf {

class Graph {
 public:
  Graph(MemoryPool& pool, Router& router);

  int16_t addNode(NodeFn fn, uint16_t nIn = 1, uint16_t nOut = 1);
  bool    connect(uint16_t fromNode, uint16_t toNode,
                  uint16_t fromPort = 0, uint16_t toPort = 0);

  Node*   node(uint16_t id);
  uint16_t nodeCount() const { return nNodes_; }

  Router& router() { return router_; }
  MemoryPool& pool() { return pool_; }

 private:
  MemoryPool& pool_;
  Router&     router_;
  Node        nodes_[GDCF_MAX_NODES];
  uint16_t    nNodes_;
};

} // namespace gdcf
