#pragma once
#include <stdint.h>
#include "Config.h"

namespace gdcf {

struct Token {
  uint16_t tag;                       // destination node id
  uint16_t port;                      // destination port
  uint16_t seq;                       // sequence number
  uint16_t flags;                     // status flags
  float    data[GDCF_TOKEN_PAYLOAD];  // payload
};

constexpr uint16_t TOKEN_FLAG_VALID = 0x0001;
constexpr uint16_t TOKEN_FLAG_LAST  = 0x0002;

} // namespace gdcf
