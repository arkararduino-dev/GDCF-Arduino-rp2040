#include "Graph.h"

namespace gdcf {

Graph::Graph(MemoryPool& pool, Router& router)
    : pool_(pool), router_(router), nNodes_(0) {}

int16_t Graph::addNode(NodeFn fn, uint16_t nIn, uint16_t nOut) {
  if (nNodes_ >= GDCF_MAX_NODES) return -1;
  uint16_t id = nNodes_++;
  void* st = pool_.allocNodeBlock(id);
  nodeInit(nodes_[id], id, fn, st, nIn, nOut);
  return static_cast<int16_t>(id);
}

bool Graph::connect(uint16_t fromNode, uint16_t toNode,
                    uint16_t fromPort, uint16_t toPort) {
  return router_.addEdge(fromNode, fromPort, toNode, toPort);
}

Node* Graph::node(uint16_t id) {
  if (id >= nNodes_) return nullptr;
  return &nodes_[id];
}

} // namespace gdcf
