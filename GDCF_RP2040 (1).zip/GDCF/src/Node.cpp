#include "Node.h"
#include "Router.h"

namespace gdcf {

void nodeInit(Node& n, uint16_t id, NodeFn fn, void* state,
              uint16_t nIn, uint16_t nOut) {
  n.id = id;
  n.fn = fn;
  n.state = state;
  n.nInputs = nIn;
  n.nOutputs = nOut;
}

void nodeExecute(Node& n, const Token& in, Router& out) {
  if (n.fn) n.fn(n, in, out);
}

} // namespace gdcf
