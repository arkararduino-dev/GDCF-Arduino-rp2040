#pragma once
#include <stdint.h>
#include <hardware/pio.h>

namespace gdcf {

class PIOEngine {
 public:
  PIOEngine();
  bool begin(uint pin);
  void put(uint32_t word);
  bool ok() const { return ok_; }

 private:
  PIO  pio_;
  int  sm_;
  uint offset_;
  bool ok_;
};

} // namespace gdcf
