#pragma once
#include <stdint.h>
#include "Token.h"
#include "MemoryPool.h"

namespace gdcf {

constexpr uint16_t GDCF_QUEUE_SIZE = 128;

struct Edge {
  uint16_t fromNode;
  uint16_t fromPort;
  uint16_t toNode;
  uint16_t toPort;
};

class Router {
 public:
  Router(MemoryPool& pool);

  bool addEdge(uint16_t fromNode, uint16_t fromPort,
               uint16_t toNode,   uint16_t toPort);

  // Called by node functions to emit a token from a given output port.
  void emit(uint16_t fromNode, uint16_t fromPort, const Token& tok);

  // Push a token directly into the queue (used by scheduler).
  bool push(const Token& tok);
  bool pop(Token& out);

  bool empty() const { return head_ == tail_; }
  uint16_t size() const {
    return (uint16_t)((head_ + GDCF_QUEUE_SIZE - tail_) % GDCF_QUEUE_SIZE);
  }

  uint16_t edgeCount() const { return nEdges_; }

 private:
  MemoryPool& pool_;
  Edge edges_[64];
  uint16_t nEdges_;

  Token    queue_[GDCF_QUEUE_SIZE];
  volatile uint16_t head_;
  volatile uint16_t tail_;
};

} // namespace gdcf
