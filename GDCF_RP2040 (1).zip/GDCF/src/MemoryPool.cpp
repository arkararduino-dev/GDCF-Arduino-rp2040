#include "MemoryPool.h"

namespace gdcf {

MemoryPool::MemoryPool() : tokensInUse_(0) {
  for (uint16_t i = 0; i < GDCF_MAX_TOKENS; ++i) used_[i] = false;
}

Token* MemoryPool::allocToken() {
  for (uint16_t i = 0; i < GDCF_MAX_TOKENS; ++i) {
    if (!used_[i]) {
      used_[i] = true;
      ++tokensInUse_;
      Token* t = &tokens_[i];
      t->tag = 0; t->port = 0; t->seq = 0; t->flags = TOKEN_FLAG_VALID;
      for (int k = 0; k < 4; ++k) t->data[k] = 0.0f;
      return t;
    }
  }
  return nullptr;
}

void MemoryPool::freeToken(Token* t) {
  if (!t) return;
  const uintptr_t base = reinterpret_cast<uintptr_t>(&tokens_[0]);
  const uintptr_t p    = reinterpret_cast<uintptr_t>(t);
  if (p < base) return;
  uint16_t idx = static_cast<uint16_t>((p - base) / sizeof(Token));
  if (idx >= GDCF_MAX_TOKENS) return;
  if (used_[idx]) {
    used_[idx] = false;
    --tokensInUse_;
  }
}

void* MemoryPool::allocNodeBlock(uint16_t idx) {
  if (idx >= GDCF_MAX_NODES) return nullptr;
  return static_cast<void*>(nodeBlocks_[idx]);
}

} // namespace gdcf
