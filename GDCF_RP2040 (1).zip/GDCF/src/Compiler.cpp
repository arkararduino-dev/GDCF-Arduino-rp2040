#include "Compiler.h"
#include "Router.h"

namespace gdcf {

Compiler::Compiler(Graph& g) : g_(g) {}

int16_t Compiler::compile(uint16_t* order, uint16_t maxLen) {
  const uint16_t N = g_.nodeCount();
  if (N == 0 || N > maxLen) return -1;

  // Since Router edges are private-ish, we approximate topo order by node id.
  // Users are expected to add nodes in dataflow order.
  for (uint16_t i = 0; i < N; ++i) order[i] = i;
  return static_cast<int16_t>(N);
}

} // namespace gdcf
