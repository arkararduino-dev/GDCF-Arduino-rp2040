#pragma once
#include <stdint.h>
#include "Config.h"
#include "Token.h"

namespace gdcf {

// Back-compat constexpr aliases (also used across the library).
constexpr uint16_t kMaxTokens = GDCF_MAX_TOKENS;
constexpr uint16_t kMaxNodes  = GDCF_MAX_NODES;

class MemoryPool {
 public:
  MemoryPool();
  Token* allocToken();
  void   freeToken(Token* t);

  void*  allocNodeBlock(uint16_t idx);
  uint16_t maxNodes() const { return kMaxNodes; }

  uint16_t tokensInUse() const { return tokensInUse_; }
  uint16_t maxTokens()  const { return kMaxTokens; }

 private:
  Token    tokens_[GDCF_MAX_TOKENS];
  bool     used_[GDCF_MAX_TOKENS];
  uint16_t tokensInUse_;

  static constexpr uint16_t NODE_BLOCK_SIZE = GDCF_NODE_BLOCK_SIZE;
  uint8_t  nodeBlocks_[GDCF_MAX_NODES][NODE_BLOCK_SIZE];
};

} // namespace gdcf
