// -----------------------------------------------------------------------------
// shift_token.pio.h
// Hand-written assembled output for shift_token.pio, compatible with the
// Raspberry Pi Pico SDK / Arduino-Pico core.
//
// The PIO program shifts one bit per clock from the TX FIFO out onto a pin,
// with autopull at 32 bits and a joined TX FIFO for deeper buffering.
// -----------------------------------------------------------------------------
#pragma once

#include <hardware/pio.h>
#include <hardware/clocks.h>

// ----- program instructions --------------------------------------------------
#define shift_token_wrap_target 0
#define shift_token_wrap        1

static const uint16_t shift_token_program_instructions[] = {
    //     .wrap_target
    0x6001, //  0: out    pins, 1         side 0
    0x1040, //  1: jmp    x--, 0          side 1
    //     .wrap
};

static const struct pio_program shift_token_program = {
    .instructions = shift_token_program_instructions,
    .length = 2,
    .origin = -1,
};

static inline pio_sm_config shift_token_program_get_default_config(uint offset) {
    pio_sm_config c = pio_get_default_sm_config();
    sm_config_set_wrap(&c, offset + shift_token_wrap_target,
                           offset + shift_token_wrap);
    sm_config_set_sideset(&c, 1, false, false);
    return c;
}

static inline void shift_token_program_init(PIO pio, uint sm, uint offset, uint pin) {
    pio_sm_config c = shift_token_program_get_default_config(offset);
    pio_gpio_init(pio, pin);
    pio_sm_set_consecutive_pindirs(pio, sm, pin, 1, true);
    sm_config_set_out_pins(&c, pin, 1);
    sm_config_set_sideset_pins(&c, pin);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);
    sm_config_set_out_shift(&c, true, true, 32);
    sm_config_set_clkdiv(&c, 1.0f);
    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
}
