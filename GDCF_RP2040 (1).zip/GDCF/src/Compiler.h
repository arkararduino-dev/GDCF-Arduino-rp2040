#pragma once
#include <stdint.h>
#include "Graph.h"

namespace gdcf {

// A tiny "compiler": validates the graph and produces a linear execution order
// (topological order) into an array supplied by the caller.
class Compiler {
 public:
  Compiler(Graph& g);

  // Returns number of nodes written into order[], or -1 on cycle/error.
  int16_t compile(uint16_t* order, uint16_t maxLen);

 private:
  Graph& g_;
};

} // namespace gdcf
