#include "GDCF.h"

namespace gdcf {

GDCF::GDCF()
    : pool_(),
      router_(pool_),
      graph_(pool_, router_),
      sched_(graph_),
      mac_() {}

void GDCF::begin() {
  sched_.begin();
}

bool GDCF::step() {
  return sched_.step();
}

} // namespace gdcf
