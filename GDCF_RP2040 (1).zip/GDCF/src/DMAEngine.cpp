#include "DMAEngine.h"
#include <hardware/dma.h>

namespace gdcf {

DMAEngine::DMAEngine() : chan_(-1), ok_(false) {}

DMAEngine::~DMAEngine() {
  if (chan_ >= 0) {
    dma_channel_unclaim(chan_);
  }
}

bool DMAEngine::begin() {
  chan_ = dma_claim_unused_channel(true);
  ok_ = (chan_ >= 0);
  return ok_;
}

bool DMAEngine::copyWords(const volatile void* src, volatile void* dst, size_t count) {
  if (!ok_) return false;
  dma_channel_config c = dma_channel_get_default_config(chan_);
  channel_config_set_transfer_data_size(&c, DMA_SIZE_32);
  channel_config_set_read_increment(&c, true);
  channel_config_set_write_increment(&c, true);
  dma_channel_configure(chan_, &c, (void*)dst, (const void*)src, count, true);
  dma_channel_wait_for_finish_blocking(chan_);
  return true;
}

} // namespace gdcf
