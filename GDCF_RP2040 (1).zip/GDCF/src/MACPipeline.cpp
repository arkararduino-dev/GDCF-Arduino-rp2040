#include "MACPipeline.h"

namespace gdcf {

MACPipeline::MACPipeline() {}

float MACPipeline::dot(const float* a, const float* b, size_t n) {
  float acc = 0.0f;
  for (size_t i = 0; i < n; ++i) acc += a[i] * b[i];
  return acc;
}

void MACPipeline::matVec(const float* A, const float* x, float* y,
                         size_t M, size_t K) {
  for (size_t i = 0; i < M; ++i) {
    y[i] = dot(A + i * K, x, K);
  }
}

float MACPipeline::fir(const float* coeffs, const float* window, size_t taps) {
  return dot(coeffs, window, taps);
}

} // namespace gdcf
