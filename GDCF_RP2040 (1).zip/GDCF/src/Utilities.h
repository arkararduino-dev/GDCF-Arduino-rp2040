#pragma once
#include <stdint.h>

namespace gdcf {

uint32_t microsNow();
void     busyWaitUs(uint32_t us);

} // namespace gdcf
