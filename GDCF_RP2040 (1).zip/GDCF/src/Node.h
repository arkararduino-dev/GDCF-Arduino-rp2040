#pragma once
#include <stdint.h>
#include "Token.h"

namespace gdcf {

class Graph;
class Router;

using NodeFn = void (*)(struct Node& self, const Token& in, Router& out);

struct Node {
  uint16_t id;
  uint16_t nInputs;
  uint16_t nOutputs;
  NodeFn   fn;
  void*    state;   // node-local memory (from MemoryPool)
};

void nodeInit(Node& n, uint16_t id, NodeFn fn, void* state,
              uint16_t nIn = 1, uint16_t nOut = 1);
void nodeExecute(Node& n, const Token& in, Router& out);

} // namespace gdcf
