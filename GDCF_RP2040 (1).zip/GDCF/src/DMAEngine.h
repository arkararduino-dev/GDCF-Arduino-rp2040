#pragma once
#include <stdint.h>
#include <stddef.h>

namespace gdcf {

class DMAEngine {
 public:
  DMAEngine();
  ~DMAEngine();

  bool begin();
  // Copy `count` 32-bit words from src to dst using DMA (blocking).
  bool copyWords(const volatile void* src, volatile void* dst, size_t count);

  int channel() const { return chan_; }

 private:
  int  chan_;
  bool ok_;
};

} // namespace gdcf
