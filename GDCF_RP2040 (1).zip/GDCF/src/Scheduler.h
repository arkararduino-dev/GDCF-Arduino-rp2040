#pragma once
#include <stdint.h>
#include "Graph.h"

namespace gdcf {

class Scheduler {
 public:
  Scheduler(Graph& graph);

  void begin();          // launches core1 worker
  bool step();           // execute one token on caller core; returns true if work done
  void dispatch(const Token& seed); // inject a token into the graph

  uint32_t executed() const { return executed_; }

  // Called from core1
  void workerLoop();

 private:
  Graph&   graph_;
  volatile uint32_t executed_;
  volatile bool     running_;
};

} // namespace gdcf
