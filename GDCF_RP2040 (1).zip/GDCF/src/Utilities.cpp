#include "Utilities.h"
#include <pico/time.h>

namespace gdcf {

uint32_t microsNow() {
  return (uint32_t)to_us_since_boot(get_absolute_time());
}

void busyWaitUs(uint32_t us) {
  busy_wait_us_32(us);
}

} // namespace gdcf
