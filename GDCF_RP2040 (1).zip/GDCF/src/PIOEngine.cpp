#include "PIOEngine.h"
#include "shift_token.pio.h"

namespace gdcf {

PIOEngine::PIOEngine() : pio_(pio0), sm_(-1), offset_(0), ok_(false) {}

bool PIOEngine::begin(uint pin) {
  pio_ = pio0;
  int sm = pio_claim_unused_sm(pio_, false);
  if (sm < 0) {
    pio_ = pio1;
    sm = pio_claim_unused_sm(pio_, false);
    if (sm < 0) return false;
  }
  sm_ = sm;
  offset_ = pio_add_program(pio_, &shift_token_program);
  shift_token_program_init(pio_, (uint)sm_, offset_, pin);
  ok_ = true;
  return true;
}

void PIOEngine::put(uint32_t word) {
  if (!ok_) return;
  pio_sm_put_blocking(pio_, (uint)sm_, word);
}

} // namespace gdcf
