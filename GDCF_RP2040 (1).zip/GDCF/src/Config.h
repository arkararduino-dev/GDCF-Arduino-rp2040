#pragma once
// GDCF compile-time configuration.
//
// Override any of these by defining the macro BEFORE including GDCF headers,
// e.g. with a build flag: -DGDCF_MAX_TOKENS=128
// or by adding `#define GDCF_MAX_TOKENS 128` above `#include <GDCF.h>` in
// your sketch. See docs/TUNING.md for sizing guidance.

// -------- Token pool --------
// Maximum number of Token structs live in the static pool.
// SRAM cost: GDCF_MAX_TOKENS * (sizeof(Token) + 1)  (Token is 32 B by default)
#ifndef GDCF_MAX_TOKENS
#define GDCF_MAX_TOKENS 64
#endif

// Number of float payload lanes per Token.
// SRAM cost per token: 12 B header + 4 B * GDCF_TOKEN_PAYLOAD.
#ifndef GDCF_TOKEN_PAYLOAD
#define GDCF_TOKEN_PAYLOAD 4
#endif

// -------- Node pool --------
// Maximum number of graph nodes.
#ifndef GDCF_MAX_NODES
#define GDCF_MAX_NODES 32
#endif

// Per-node scratch block (bytes). Increase for kernels that need more state.
#ifndef GDCF_NODE_BLOCK_SIZE
#define GDCF_NODE_BLOCK_SIZE 64
#endif
