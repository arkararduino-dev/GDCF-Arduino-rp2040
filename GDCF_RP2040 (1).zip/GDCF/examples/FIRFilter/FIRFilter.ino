// GDCF example: simple 5-tap FIR filter using MAC pipeline.
#include <GDCF.h>
using namespace gdcf;

static GDCF fabric;

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {}

  const size_t TAPS = 5;
  float coeffs[TAPS] = {0.2f, 0.2f, 0.2f, 0.2f, 0.2f};
  float window[TAPS] = {1.0f, 2.0f, 3.0f, 4.0f, 5.0f};
  float y = fabric.mac().fir(coeffs, window, TAPS);
  Serial.print("FIR out = "); Serial.println(y, 4);
}

void loop() {}
