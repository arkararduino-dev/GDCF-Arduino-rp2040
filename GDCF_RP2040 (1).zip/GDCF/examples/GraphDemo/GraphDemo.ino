// GDCF example: three-stage graph a -> b -> c passing tokens.
#include <GDCF.h>
using namespace gdcf;

static GDCF fabric;

static void addOne(Node& self, const Token& in, Router& out) {
  Token t = in; t.data[0] += 1.0f;
  out.emit(self.id, 0, t);
}
static void mulTwo(Node& self, const Token& in, Router& out) {
  Token t = in; t.data[0] *= 2.0f;
  out.emit(self.id, 0, t);
}
static void sink(Node& self, const Token& in, Router& out) {
  (void)self; (void)out;
  Serial.print("result="); Serial.println(in.data[0]);
}

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {}

  int16_t a = fabric.graph().addNode(addOne);
  int16_t b = fabric.graph().addNode(mulTwo);
  int16_t c = fabric.graph().addNode(sink);
  fabric.graph().connect((uint16_t)a, (uint16_t)b);
  fabric.graph().connect((uint16_t)b, (uint16_t)c);

  fabric.begin();

  Token seed;
  seed.tag = (uint16_t)a; seed.port = 0; seed.seq = 0; seed.flags = TOKEN_FLAG_VALID;
  seed.data[0] = 3.0f;
  fabric.dispatch(seed);
}

void loop() {
  fabric.step();
  delay(200);
}
