// GDCF example: minimal CNN skeleton - 1D conv layer over a small input.
#include <GDCF.h>
using namespace gdcf;

static GDCF fabric;

static void relu(float* v, size_t n) {
  for (size_t i = 0; i < n; ++i) if (v[i] < 0) v[i] = 0;
}

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {}

  const size_t IN = 8;
  const size_t K  = 3;
  float in[IN]  = {1, -1, 2, -2, 3, -3, 4, -4};
  float k[K]    = {0.5f, -0.25f, 0.25f};
  float out[IN - K + 1];

  for (size_t i = 0; i + K <= IN; ++i) {
    out[i] = fabric.mac().dot(&in[i], k, K);
  }
  relu(out, IN - K + 1);

  for (size_t i = 0; i < IN - K + 1; ++i) {
    Serial.print(out[i]); Serial.print(' ');
  }
  Serial.println();
}

void loop() {}
