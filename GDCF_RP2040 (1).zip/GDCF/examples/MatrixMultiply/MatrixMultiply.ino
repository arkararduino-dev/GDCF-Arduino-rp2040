// GDCF example: 4x4 * 4-vector matrix multiply using the MAC pipeline.
#include <GDCF.h>
using namespace gdcf;

static GDCF fabric;

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {}

  const size_t M = 4, K = 4;
  float A[M * K] = {
    1, 2, 3, 4,
    5, 6, 7, 8,
    9,10,11,12,
   13,14,15,16
  };
  float x[K] = {1, 0, 1, 0};
  float y[M] = {0};

  fabric.mac().matVec(A, x, y, M, K);

  for (size_t i = 0; i < M; ++i) {
    Serial.print("y["); Serial.print(i); Serial.print("]="); Serial.println(y[i]);
  }
}

void loop() {}
