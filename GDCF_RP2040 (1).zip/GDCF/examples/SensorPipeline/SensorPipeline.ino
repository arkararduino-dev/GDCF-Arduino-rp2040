// GDCF example: sensor -> scale -> print pipeline via graph tokens.
#include <GDCF.h>
using namespace gdcf;

static GDCF fabric;

static void scaleNode(Node& self, const Token& in, Router& out) {
  (void)self;
  Token t = in;
  for (int i = 0; i < 4; ++i) t.data[i] *= 2.0f;
  out.emit(self.id, 0, t);
}

static void printNode(Node& self, const Token& in, Router& out) {
  (void)self; (void)out;
  Serial.print("sample=");
  Serial.println(in.data[0]);
}

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {}

  int16_t scale = fabric.graph().addNode(scaleNode);
  int16_t sink  = fabric.graph().addNode(printNode);
  fabric.graph().connect((uint16_t)scale, (uint16_t)sink);

  fabric.begin();

  Token t;
  t.tag = (uint16_t)scale; t.port = 0; t.seq = 0; t.flags = TOKEN_FLAG_VALID;
  t.data[0] = 21.0f; t.data[1] = 0; t.data[2] = 0; t.data[3] = 0;
  fabric.dispatch(t);
}

void loop() {
  fabric.step();
  delay(500);
}
